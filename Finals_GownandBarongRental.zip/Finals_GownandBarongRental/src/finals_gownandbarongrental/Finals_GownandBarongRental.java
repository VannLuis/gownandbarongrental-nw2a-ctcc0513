 package finals_gownandbarongrental;
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.awt.BorderLayout;
import java.awt.FlowLayout;


public class Finals_GownandBarongRental {

    JFrame frame;
    JLabel titleLabel;
    JLabel loginLabel;
    JLabel emailLabel;
    JLabel passwordLabel;
    JTextField emailTextField;
    JPasswordField passwordField;
    JButton loginButton;
    JButton signUpButton;
    SignUpWindow signUpWindow;
    GownAndBarongOptionsWindow optionsWindow;
    ShoppingCart cart;

    public Finals_GownandBarongRental() {
        cart = new ShoppingCart();
        initialize();
    }

    void initialize() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(783, 632);
        frame.setLayout(new GridBagLayout());
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(new Color(0xE2CACA));

        titleLabel = new JLabel("Gown and Barong Rental");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));

        loginLabel = new JLabel("Log In");
        loginLabel.setFont(new Font("Arial", Font.BOLD, 20));

        emailLabel = new JLabel("Email:");
        emailTextField = new JTextField();
        emailTextField.setPreferredSize(new Dimension(350, 30));

        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(350, 30));

        loginButton = new JButton("Log In");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailTextField.getText();
                String password = new String(passwordField.getPassword());

                if (email.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter both email and password.", "Login Error", JOptionPane.ERROR_MESSAGE);
                } else if (signUpWindow != null && email.equals(signUpWindow.getEmail()) && password.equals(signUpWindow.getPassword())) {
                    JOptionPane.showMessageDialog(frame, "Login Successful!");
                    openGownAndBarongOptionsWindow();
                    frame.setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid email or password. Please try again.", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        signUpButton = new JButton("Sign Up");
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSignUpWindow();
                frame.setVisible(false);
            }
        });

        loginButton.setBackground(new Color(188, 143, 219));
        signUpButton.setBackground(new Color(188, 143, 219));
        signUpButton.setForeground(Color.WHITE);

        GroupLayout layout = new GroupLayout(frame.getContentPane());
        frame.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(56)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(titleLabel)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addComponent(emailLabel)
                                                        .addComponent(passwordLabel))
                                                .addGap(18)
                                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(emailTextField)
                                                        .addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)))
                                        .addComponent(loginLabel)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(loginButton)
                                                .addGap(18)
                                                .addComponent(signUpButton)))
                                .addContainerGap(54, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(39)
                                .addComponent(titleLabel)
                                .addGap(35)
                                .addComponent(loginLabel)
                                .addGap(18)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(emailLabel)
                                        .addComponent(emailTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addGap(18)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(passwordLabel)
                                        .addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addGap(18)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(loginButton)
                                        .addComponent(signUpButton))
                                .addContainerGap(45, Short.MAX_VALUE))
        );

        frame.pack();
        frame.setVisible(true);
    }

    void openSignUpWindow() {
        signUpWindow = new SignUpWindow();
        signUpWindow.setVisible(true);
    }

    void openGownAndBarongOptionsWindow() {
        optionsWindow = new GownAndBarongOptionsWindow();
        optionsWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        optionsWindow.setVisible(true);
    }

    class SignUpWindow extends JFrame {
        JLabel titleLabel;
        JLabel signUpLabel;
        JLabel emailLabel;
        JLabel passwordLabel;
        JLabel confirmPasswordLabel;
        JTextField emailTextField;
        JPasswordField passwordField;
        JPasswordField confirmPasswordField;
        JButton signUpButton;
        JButton cancelButton;

        public SignUpWindow() {
            initialize();
        }

        void initialize() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setTitle("Sign Up");
            setSize(400, 300);
            setLocationRelativeTo(null);
            setLayout(new GridBagLayout());
            getContentPane().setBackground(new Color(0xE2CACA));

            titleLabel = new JLabel("Gown and Barong Rental");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 28));

            signUpLabel = new JLabel("Sign Up");
            signUpLabel.setFont(new Font("Arial", Font.BOLD, 20));

            emailLabel = new JLabel("Email:");
            emailTextField = new JTextField();
            emailTextField.setPreferredSize(new Dimension(350, 30));

            passwordLabel = new JLabel("Password:");
            passwordField = new JPasswordField();
            passwordField.setPreferredSize(new Dimension(350, 30));

            confirmPasswordLabel = new JLabel("Confirm Password:");
            confirmPasswordField = new JPasswordField();
            confirmPasswordField.setPreferredSize(new Dimension(350, 30));

            signUpButton = new JButton("Sign Up");
            signUpButton.setBackground(new Color(188, 143, 219));
            signUpButton.setForeground(Color.WHITE);
            signUpButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String email = emailTextField.getText();
                    String password = new String(passwordField.getPassword());
                    String confirmPassword = new String(confirmPasswordField.getPassword());

                    if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the fields.", "Sign Up Error", JOptionPane.ERROR_MESSAGE);
                    } else if (password.equals(confirmPassword)) {
                        JOptionPane.showMessageDialog(null, "Sign Up Successful!");
                        dispose();
                        frame.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Passwords do not match. Please try again.", "Sign Up Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            cancelButton = new JButton("Cancel");
            cancelButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    dispose();
                    frame.setVisible(true);
                }
            });

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.anchor = GridBagConstraints.NORTH;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(10, 10, 10, 10);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            add(titleLabel, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            add(signUpLabel, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            add(emailLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            add(emailTextField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            add(passwordLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            add(passwordField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            add(confirmPasswordLabel, gbc);

            gbc.gridx = 1;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            add(confirmPasswordField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridwidth = 1;
            add(signUpButton, gbc);

            gbc.gridx = 1;
            gbc.gridy = 5;
            gbc.gridwidth = 1;
            add(cancelButton, gbc);
        }

        public String getEmail() {
            return emailTextField.getText();
        }

        public String getPassword() {
            return new String(passwordField.getPassword());
        }
    }

    class GownAndBarongOptionsWindow extends JFrame {
        JLabel titleLabel;
        ShoppingCart cart;
        JButton cartListButton;
        JButton buyButton;
        JButton logoutButton;

        public GownAndBarongOptionsWindow() {
            this.cart = new ShoppingCart();
            initialize();
        }

        void initialize() {
            
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setTitle("Gown and Barong Rental");
            setSize(1000, 800);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());
            getContentPane().setBackground(new Color(0xE2CACA));

            JPanel titlePanel = new JPanel(new BorderLayout());
            titlePanel.setBackground(new Color(0xB2CAB1));
            titlePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            titleLabel = new JLabel("Gown and Barong Rental");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
            titleLabel.setHorizontalAlignment(JLabel.CENTER);

            titlePanel.add(titleLabel, BorderLayout.NORTH);
            add(titlePanel, BorderLayout.NORTH);
            

            JPanel contentPanel = new JPanel(new GridLayout(5, 2, 10, 10));
            contentPanel.setBackground(new Color(0xE2CACA));
            contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            contentPanel.add(createItemPanel("Evening Gown", "EveningGown.jpg", "PHP 1,999"));
            contentPanel.add(createItemPanel("Chinoy Barong", "ChinoyBarong.png", "PHP 2,389"));
            contentPanel.add(createItemPanel("Bouffant Skirt Gown", "BouFant.png", "PHP 12,816"));
            contentPanel.add(createItemPanel("Custom Classic Barong", "ClassicCustom.png", "PHP 7,499"));
            contentPanel.add(createItemPanel("Bustle Gown", "BustleGown.png", "PHP 4,742"));

            contentPanel.add(createItemPanel("Biggie Barong", "BiggieBarong.png", "PHP 1,999"));
            contentPanel.add(createItemPanel("Sheath Gown", "SheathGown.jpg", "PHP 12,816"));
            contentPanel.add(createItemPanel("Gardan Barong", "GardanBarong.jpg", "PHP 3,099"));
            contentPanel.add(createItemPanel("Circular Skirt Gown", "CircularSkirt.jpg", "PHP 4,899"));
            contentPanel.add(createItemPanel("Short Sleeve Barong", "ShortSleeve.png", "PHP 6,599"));

            JScrollPane scrollPane = new JScrollPane(contentPanel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            add(scrollPane, BorderLayout.CENTER);
            
            logoutButton = new JButton("Log Out");
            logoutButton.setBackground(new Color(188, 143, 219));
            logoutButton.setForeground(Color.WHITE);
            logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(true); 
                dispose(); 
            }
        });

            cartListButton = new JButton("Cart List");
            cartListButton.setBackground(new Color(188, 143, 219));
            cartListButton.setForeground(Color.WHITE);
            cartListButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    showCartList();
                }
            });

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(cartListButton);
            buttonPanel.add(logoutButton);

            add(buttonPanel, BorderLayout.SOUTH);
        }

        private void showCartList() {
        StringBuilder cartList = new StringBuilder("Cart List:\n");
        double totalAmount = 0;

        for (ShoppingCartItem item : cart.getItems()) {
            cartList.append(item.getItemName())
                    .append(" (").append(item.getRentalDays()).append(" days) - ")
                    .append("PHP ").append(item.getTotalPrice()).append("\n");

            totalAmount += item.getTotalPrice();
        }

        int response = JOptionPane.showConfirmDialog(this, cartList.toString() + "\nTotal: PHP " + totalAmount + "\nProceed to Payment?", "Cart List", JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            String cashInput = JOptionPane.showInputDialog(this, "Enter the amount in cash:");

            try {
                double cashAmount = Double.parseDouble(cashInput);

                if (cashAmount >= totalAmount) {
                    JOptionPane.showMessageDialog(this, "Payment successful. Thank you! Payment made in cash. Change: PHP " + (cashAmount - totalAmount));
                    cart.getItems().clear();
                } else {
                    JOptionPane.showMessageDialog(this, "Insufficient cash. Please enter a sufficient amount.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input for cash amount. Please enter a valid number.");
            }
        }
    }

    private void processPayment(Set<ShoppingCartItem> items, String cardNumber) {
        PaymentWindow paymentWindow = new PaymentWindow(items, cardNumber);
        paymentWindow.setVisible(true);
    }

        private void updateCartButtonLabel() {
        }

private JPanel createItemPanel(final String itemName, String imageName, final String price) {
    final String finalItemName = itemName;
    final String finalPrice = price;
    
    Color backgroundColor = new Color(0xE2CACA);

    JPanel itemPanel = new JPanel(new BorderLayout());
    itemPanel.setBackground(new Color(0xE2CACA));
    itemPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

    JLabel nameLabel = new JLabel(itemName);
    nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
    nameLabel.setHorizontalAlignment(JLabel.CENTER);
    itemPanel.add(nameLabel, BorderLayout.NORTH);
    
    ImageIcon itemImage = createImageIcon(imageName); 
    if (itemImage != null) {
        Image scaledImage = itemImage.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel imageLabel = new JLabel(scaledIcon); 
        imageLabel.setHorizontalAlignment(JLabel.CENTER);

        itemPanel.add(imageLabel, BorderLayout.CENTER);
    } else {
        System.err.println("Image not found: " + imageName);
    }

    JLabel priceLabel = new JLabel(price);
    priceLabel.setFont(new Font("Arial", Font.PLAIN, 14));
    priceLabel.setHorizontalAlignment(JLabel.CENTER);
    itemPanel.add(priceLabel, BorderLayout.SOUTH);
    priceLabel.setBackground(backgroundColor); 
    priceLabel.setOpaque(true);

    JButton addToCartButton = new JButton("Add to Cart");
    addToCartButton.setBackground(backgroundColor); 
    addToCartButton.setOpaque(true);
    addToCartButton.setBorderPainted(false); 
    
    JButton buyButton = new JButton("Buy");
    buyButton.setBackground(backgroundColor); 
    buyButton.setOpaque(true);
    buyButton.setBorderPainted(false);

    Color buttonColor = new Color(0xB2CAB1);
    addToCartButton.setBackground(buttonColor);
    buyButton.setBackground(buttonColor);
    
    

    addToCartButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            String rentalDaysInput = JOptionPane.showInputDialog("Enter the number of rental days for " + itemName + ":");

            if (rentalDaysInput == null || rentalDaysInput.isEmpty()) {
                return;
            }

            try {
                int rentalDays = Integer.parseInt(rentalDaysInput);
                double originalPrice = Double.parseDouble(price.replaceAll("[^\\d.]", ""));
                ShoppingCartItem cartItem = new ShoppingCartItem(itemName, originalPrice, rentalDays);
                cart.addItem(cartItem);
                updateCartButtonLabel();

                JOptionPane.showMessageDialog(null, "Added to Cart: " + itemName +
                        " (Original Price: " + cartItem.getOriginalPrice() +
                        ", Total: " + cartItem.getTotalPrice() +
                        ") for " + rentalDays + " days");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid input for rental days. Please enter a valid number.");
            }
        }
    });

    buyButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            showPaymentDetails(itemName, price);
        }
    });

    JPanel buttonsPanel = new JPanel();

    buttonsPanel.add(addToCartButton);
    buttonsPanel.add(buyButton);

    JPanel bottomPanel = new JPanel(new BorderLayout());
    bottomPanel.add(priceLabel, BorderLayout.NORTH);
    bottomPanel.add(buttonsPanel, BorderLayout.SOUTH);
    itemPanel.add(bottomPanel, BorderLayout.SOUTH);

    return itemPanel;
}
protected ImageIcon createImageIcon(String imageName) {
    java.net.URL imgURL = getClass().getResource("/images/" + imageName);
    System.out.println("Loading image: " + imgURL); 
    if (imgURL != null) {
        return new ImageIcon(imgURL);
    } else {
        System.err.println("Couldn't find file: " + imageName);
        return null;
    }
}

private void showPaymentDetails(String itemName, String price) {
    String rentalDaysInput = JOptionPane.showInputDialog("Enter the number of rental days for " + itemName + ":");

    if (rentalDaysInput == null || rentalDaysInput.isEmpty()) {
        return;
    }

    try {
        int rentalDays = Integer.parseInt(rentalDaysInput);
        double originalPrice = Double.parseDouble(price.replaceAll("[^\\d.]", ""));
        ShoppingCartItem cartItem = new ShoppingCartItem(itemName, originalPrice, rentalDays);
        
        double totalPrice = cartItem.getTotalPrice();

        String paymentDetails = String.format(
                "Item: %s\nRental Days: %d\nTotal Price: PHP %.2f", itemName, rentalDays, totalPrice);

        int response = JOptionPane.showConfirmDialog(null, paymentDetails + "\nProceed to Payment?", "Payment Details", JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            String cashInput = JOptionPane.showInputDialog(null, "Enter the amount in cash:");

            try {
                double cashAmount = Double.parseDouble(cashInput);

                if (cashAmount >= totalPrice) {
                    double change = cashAmount - totalPrice;

                    String receipt = String.format(
                            "Item: %s\nRental Days: %d\nTotal Price: PHP %.2f\nPayment: PHP %.2f\nChange: PHP %.2f",
                            itemName, rentalDays, totalPrice, cashAmount, change);

                    JOptionPane.showMessageDialog(null, "Payment successful. Thank you!\n\nReceipt:\n" + receipt);

                    cart.getItems().clear();
                    updateCartButtonLabel();
                } else {
                    JOptionPane.showMessageDialog(null, "Insufficient cash. Please enter a sufficient amount.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input for cash amount. Please enter a valid number.");
            }
        }
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Invalid input for rental days. Please enter a valid number.");
    }
  }
}
    class ShoppingCartItem {
    private String itemName;
    private double originalPrice; 
    private double totalPrice;
    private int rentalDays;
    List<ShoppingCartItem> items;

    public ShoppingCartItem(String itemName, double price, int rentalDays) {
        this.itemName = itemName;
        this.originalPrice = price;
        this.rentalDays = rentalDays;
        this.totalPrice = calculateTotalPrice();
        this.items = new ArrayList<>();
    }
    
    private double calculateTotalPrice() {
        return originalPrice * rentalDays;
    }

    public String getItemName() {
        return itemName;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }
    
    public List<ShoppingCartItem> getItems() {
        return items;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public int getRentalDays() {
        return rentalDays;
    }
}
    class ShoppingCart {
    private List<ShoppingCartItem> items;

    public ShoppingCart() {
        this.items = new ArrayList<>();
    }

    public List<ShoppingCartItem> getItems() {
        return items;
    }

    public void addItem(ShoppingCartItem item) {
        items.add(0, item);
    }
}
    


    class PaymentWindow extends JFrame {
    private Set<ShoppingCartItem> items;
    private String cardNumber;

    public PaymentWindow(Set<ShoppingCartItem> items, String cardNumber) {
        this.items = items;
        this.cardNumber = cardNumber;
        initialize();
    }

    public PaymentWindow(String itemName, String price) {
        this.items = new HashSet<>();
        this.cardNumber = ""; 
        initialize();
    }

    private void initialize() {
        setTitle("Payment Details");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4 + items.size(), 2)); 

        add(new JLabel("Item Name"));
        add(new JLabel("Price"));

        double totalAmount = 0;

        for (ShoppingCartItem item : items) {
            JLabel itemNameValue = new JLabel(item.getItemName());
            JLabel priceValue = new JLabel("PHP " + item.getOriginalPrice());

            add(itemNameValue);
            add(priceValue);

            totalAmount += item.getOriginalPrice();
        }

        add(new JLabel("Total"));
        add(new JLabel("PHP " + totalAmount));

        JLabel cardNumberLabel = new JLabel("Card Number:");
        JTextField cardNumberField = new JTextField();

        JButton payButton = new JButton("Pay");

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Payment successful. Thank you!");
                dispose();
            }
        });

        add(cardNumberLabel);
        add(cardNumberField);
        add(new JLabel()); 
        add(payButton);

        setVisible(true);
    }
}
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Finals_GownandBarongRental();
       });
    }
  }